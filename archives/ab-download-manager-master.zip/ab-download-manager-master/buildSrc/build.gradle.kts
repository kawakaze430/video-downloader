plugins {
    `kotlin-dsl`
}
repositories {
    gradlePluginPortal()
    mavenCentral()
    google()
}
dependencies {
    implementation(libs.pluginKotlin)
    implementation(libs.pluginAndroidGradle)
    implementation(libs.pluginComposeCompiler)
    implementation(libs.pluginKsp)
    implementation(libs.pluginSerialization)
    implementation(libs.pluginChangeLog)
    implementation(libs.pluginBuildConfig)
    implementation(libs.pluginAboutLibraries)
    implementation(libs.pluginGradleVersions)
    implementation(libs.nucleus.plugin)
    implementation(libs.kotlinx.rpc.gradlePlugin)
    implementation(libs.semver)
    implementation("ir.amirab.util:platform:1")
    implementation("ir.amirab.plugin:git-version-plugin:1")
    implementation("ir.amirab.plugin:installer-plugin:1")
    implementation("ir.amirab.plugin:common-android:1")
}
