# Contributing to AB Download Manager

Thank you for your interest in contributing to AB Download Manager! I appreciate any help you can offer.

## What Contributions Are Accepted?

I welcome the following types of contributions:

- **Bug Reports**: If you find a bug, please report it by opening an issue with details about the problem.

- **Feature Requests**: Have an idea for a new feature? Let me know by opening an issue or starting a discussion.

- **Translations**: You can translate AB Download Manager into other languages on Crowdin. See the Translations section
  below for more information.

- **Pull Requests**: If you’d like to contribute code, feel free to submit a pull request. Just make sure to read the guidelines below before you start.

## Bug Reports

#### Before opening an issue:

- Make sure you are using the [latest version](https://github.com/amir1376/ab-download-manager/releases/latest).
- Search existing issues.
- Include steps to reproduce the problem.
- Include logs when applicable.

#### After opening an issue:

- If you find the cause of the issue, share it before closing the issue. Documenting solutions helps other users,
  reduces duplicate reports, and saves everyone time.

## Translations

If you’d like to help translate AB Download Manager into another language, or improve existing translations, you can do
so on Crowdin. Here’s how:

- Visit the project in [Crowdin](https://crowdin.com/project/ab-download-manager)
- Please DO NOT submit translations via pull requests.
- If you want to add a new language, please see [here](https://github.com/amir1376/ab-download-manager/issues/144)

## Pull Requests

If you're ready to contribute code, that's awesome! Before you start, here’s what you need to know about creating a pull request (PR):

- **Discuss First**: Before you start working on a PR, please open an issue or discussion to explain what you want to do. This helps me understand your idea and make sure it's something that can be merged. It also saves time if changes are needed.

- **Fork the Repo**: Fork this repository to your own GitHub account. This creates your own copy where you can make changes.

- **Create a Branch**: In your forked repository, create a new branch for your changes. Give it a descriptive name, like feature/add-some-feature or fix/some-error.

- **Make Your Changes**: Now you can start coding! Make sure your changes follow the project’s coding standards.

- **Submit the PR**: Once you're happy with your changes, push your branch to your fork and submit a pull request. In the PR description, explain what changes you made and why.

- **Review & Feedback**: I’ll review your PR as soon as I can. There might be some feedback or requests for changes, so be ready to make adjustments if needed.

- **Merging**: If everything looks good, I’ll merge your PR into the master branch.

### Pull Request Requirements

You are responsible for testing, debugging, and maintaining your pull request until it is merged.

Vibe coding is not allowed. DO NOT submit AI-generated code and expect review cycles to shape it into a working implementation. If you submit a pull request, you must understand the code completely, verify that it works, and address issues yourself.

Pull requests that primarily shift development, testing, or debugging work to reviewers may be closed without review.
