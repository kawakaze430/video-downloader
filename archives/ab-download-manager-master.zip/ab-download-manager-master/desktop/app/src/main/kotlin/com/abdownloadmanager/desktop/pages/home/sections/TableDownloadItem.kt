package com.abdownloadmanager.desktop.pages.home.sections

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.abdownloadmanager.resources.Res
import com.abdownloadmanager.shared.ui.widget.CheckBox
import com.abdownloadmanager.shared.ui.widget.Text
import com.abdownloadmanager.shared.util.*
import com.abdownloadmanager.shared.util.category.Category
import com.abdownloadmanager.shared.util.downloaderror.DownloadErrorReason
import com.abdownloadmanager.shared.util.ui.LocalContentColor
import com.abdownloadmanager.shared.util.ui.myColors
import com.abdownloadmanager.shared.util.ui.theme.myTextSizes
import com.abdownloadmanager.shared.util.ui.widget.MyIcon
import ir.amirab.downloader.downloaditem.DownloadJobStatus
import ir.amirab.downloader.monitor.CompletedDownloadItemState
import ir.amirab.downloader.monitor.IDownloadItemState
import ir.amirab.downloader.monitor.ProcessingDownloadItemState
import ir.amirab.downloader.utils.ExceptionUtils
import ir.amirab.util.compose.resources.MyStringResource
import ir.amirab.util.compose.resources.myStringResource
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.datetime.TimeZone
import kotlinx.datetime.format
import kotlinx.datetime.periodUntil
import kotlinx.datetime.toLocalDateTime
import kotlin.time.Clock
import kotlin.time.Duration.Companion.seconds
import kotlin.time.Instant

val LocalDownloadItemProperties =
    compositionLocalOf<DownloadItemProperties> { error("not provided download properties") }


data class DownloadItemProperties(
    val isSelected: Boolean,
    val iDownloadItemState: IDownloadItemState,
)


@Composable
private fun isSelected(): Boolean {
    return LocalDownloadItemProperties.current.isSelected
}


@Composable
fun CheckCell(
    onCheckedChange: (Long, Boolean) -> Unit,
    dItemState: IDownloadItemState,
) {
    val isChecked = isSelected()
    CheckBox(
        value = isChecked,
        onValueChange = {
            onCheckedChange(dItemState.id, it)
        },
        modifier = Modifier.focusProperties {
            canFocus = false
        },
        size = 12.dp,
    )
}

@Composable
fun NameCell(
    itemState: IDownloadItemState,
    category: Category?,
    fileIconProvider: FileIconProvider,
) {
    val fileIcon = fileIconProvider.rememberIcon(itemState.name)
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        MyIcon(
            icon = fileIcon,
            modifier = Modifier.size(16.dp),
            contentDescription = null,
//            tint = LocalContentColor.current / 75
        )
        Spacer(Modifier.width(6.dp))
        Column {
            Text(
                text = itemState.name,
                maxLines = 1,
                fontSize = myTextSizes.base,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                category?.name ?: myStringResource(Res.string.general), maxLines = 1, fontSize = myTextSizes.xs,
                color = LocalContentColor.current / 50
            )
        }
    }

}

@Composable
fun TimeLeftCell(
    itemState: IDownloadItemState,
) {
    (itemState as? ProcessingDownloadItemState)?.remainingTime?.let { remaining ->
        Text(
            text = convertTimeRemainingToHumanReadable(remaining, TimeNames.ShortNames),
            maxLines = 1,
            fontSize = myTextSizes.base,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun DateAddedCell(
    itemState: IDownloadItemState,
) {
    DateCell(itemState, dateSelector = IDownloadItemState::dateAdded)
}

@Composable
fun DateStartedCell(
    itemState: IDownloadItemState,
) {
    DateCell(itemState, dateSelector = IDownloadItemState::startTime)
}

@Composable
fun DateFinishedCell(
    itemState: IDownloadItemState,
) {
    DateCell(itemState, dateSelector = IDownloadItemState::completeTime)
}

@Composable
fun DateCell(
    itemState: IDownloadItemState,
    dateSelector: (IDownloadItemState) -> Long
) {
    var dateString by remember { mutableStateOf("") }
    val useRelativeDateTime = LocalUseRelativeDateTime.current

    val date = dateSelector(itemState)
    LaunchedEffect(
        date,
        useRelativeDateTime,
    ) {
        if (date <= 0L) {
            // don't show date for 0 and negative values
            dateString = ""
            return@LaunchedEffect
        }
        val instant = Instant.fromEpochMilliseconds(date)
        if (useRelativeDateTime) {
            while (isActive) {
                val now = Clock.System.now()
                val period = now.periodUntil(instant, TimeZone.UTC)
                val relativeTime = prettifyRelativeTime(period)
                dateString = relativeTime
                delay(1.seconds)
            }
        } else {
            val dateTime = instant.toLocalDateTime(TimeZone.currentSystemDefault())
            dateString = dateTime.format(MyDateAndTimeFormats.fullDateTime)
        }
    }
    Text(
        text = dateString,
        maxLines = 1,
        fontSize = myTextSizes.base,
        overflow = TextOverflow.Ellipsis,
    )

}

@Composable
fun LocationCell(
    itemState: IDownloadItemState,
) {
    Text(
        text = itemState.folder,
        maxLines = 1,
        fontSize = myTextSizes.base,
        overflow = TextOverflow.Ellipsis,
    )
}


@Composable
fun SpeedCell(
    itemState: IDownloadItemState,
) {
    (itemState as? ProcessingDownloadItemState)?.speed?.let { remaining ->
        if (itemState.status == DownloadJobStatus.Downloading) {
            Text(
                text = convertPositiveSpeedToHumanReadable(
                    remaining,
                    LocalSpeedUnit.current,
                ),
                maxLines = 1,
                fontSize = myTextSizes.base,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
fun SizeCell(
    item: IDownloadItemState,
) {
    item.contentLength.let {
        Text(
            convertPositiveSizeToHumanReadable(
                it,
                LocalSizeUnit.current
            ).rememberString(),
            maxLines = 1,
            fontSize = myTextSizes.base,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun StatusCell(
    itemState: IDownloadItemState,
    errorReason: DownloadErrorReason?,
) {
    when (itemState) {
        is ProcessingDownloadItemState -> {
            when (val status = itemState.status) {
                is DownloadJobStatus.Canceled -> {
                    ProgressAndPercent(
                        percent = itemState.percent,
                        status = if (ExceptionUtils.isNormalCancellation(status.e)) {
                            if (!itemState.gotAnyProgress) {
                                DownloadProgressStatus.Added
                            } else {
                                DownloadProgressStatus.Paused
                            }
                        } else {
                            DownloadProgressStatus.Error
                        },
                        gotAnyProgress = itemState.gotAnyProgress,
                        isWaiting = itemState.isWaiting,
                        errorReason = errorReason,
                    )
                }

                DownloadJobStatus.IDLE -> {
                    ProgressAndPercent(
                        percent = itemState.percent,
                        status = if (!itemState.gotAnyProgress) {
                            DownloadProgressStatus.Added
                        } else {
                            DownloadProgressStatus.Paused
                        },
                        gotAnyProgress = itemState.gotAnyProgress,
                        isWaiting = itemState.isWaiting,
                    )
                }

                DownloadJobStatus.Downloading -> {
                    ProgressAndPercent(
                        percent = itemState.percent,
                        status = DownloadProgressStatus.Downloading,
                        gotAnyProgress = itemState.gotAnyProgress,
                        isWaiting = itemState.isWaiting,
                    )
                }

                is DownloadJobStatus.PreparingFile -> {
                    ProgressAndPercent(
                        percent = status.percent,
                        status = DownloadProgressStatus.CreatingFile,
                        gotAnyProgress = itemState.gotAnyProgress,
                        isWaiting = itemState.isWaiting,
                    )
                }

                is DownloadJobStatus.Resuming -> {
                    ProgressAndPercent(
                        percent = itemState.percent,
                        status = DownloadProgressStatus.Resuming,
                        gotAnyProgress = itemState.gotAnyProgress,
                        isWaiting = itemState.isWaiting,
                    )
                }

                is DownloadJobStatus.Retrying -> {
                    ProgressAndPercent(
                        percent = itemState.percent,
                        status = DownloadProgressStatus.Retrying,
                        gotAnyProgress = itemState.gotAnyProgress,
                        isWaiting = itemState.isWaiting,
                    )
                }

                DownloadJobStatus.Finished,
                    -> SimpleStatus(
                    myStringResource(itemState.status.toStringResource()),
                    myColors.success,
                )
            }
        }

        is CompletedDownloadItemState -> {
            SimpleStatus(
                myStringResource(Res.string.finished),
                myColors.success,
            )
        }
    }

}

@Composable
private fun DownloadJobStatus.toStringResource(): MyStringResource {
    return when (this) {
        is DownloadJobStatus.Canceled -> {
            Res.string.canceled
        }

        DownloadJobStatus.Downloading -> {
            Res.string.downloading
        }

        DownloadJobStatus.Finished -> {
            Res.string.finished
        }

        DownloadJobStatus.IDLE -> {
            Res.string.idle
        }

        is DownloadJobStatus.PreparingFile -> {
            Res.string.preparing_file
        }

        DownloadJobStatus.Resuming -> {
            Res.string.resuming
        }

        is DownloadJobStatus.Retrying -> {
            Res.string.retrying
        }
    }
}

private fun DownloadProgressStatus.toStringResource(): MyStringResource {
    return when (this) {
        DownloadProgressStatus.Added -> {
            Res.string.added
        }

        DownloadProgressStatus.Error -> {
            Res.string.error
        }

        DownloadProgressStatus.Paused -> {
            Res.string.paused
        }

        DownloadProgressStatus.CreatingFile -> {
            Res.string.creating_file
        }

        DownloadProgressStatus.Resuming -> {
            Res.string.resuming
        }

        DownloadProgressStatus.Downloading -> {
            Res.string.downloading
        }

        DownloadProgressStatus.Retrying -> {
            Res.string.retrying
        }
    }
}

@Composable
private fun SimpleStatus(
    string: String,
    color: Color = LocalContentColor.current
) {
    Text(
        text = string,
        maxLines = 1,
        fontSize = myTextSizes.base,
        overflow = TextOverflow.Ellipsis,
        color = color,
    )
}

private enum class DownloadProgressStatus {
    Added, Error, Paused, CreatingFile, Resuming, Downloading, Retrying
}

@Composable
private fun ProgressAndPercent(
    percent: Int?,
    status: DownloadProgressStatus,
    gotAnyProgress: Boolean,
    isWaiting: Boolean,
    errorReason: DownloadErrorReason? = null,
) {
    var isError = false
    val background = when (status) {
        DownloadProgressStatus.Error -> {
            isError = true
            myColors.errorGradient
        }

        DownloadProgressStatus.Paused, DownloadProgressStatus.Added -> myColors.warningGradient
        DownloadProgressStatus.CreatingFile -> myColors.infoGradient
        DownloadProgressStatus.Resuming -> myColors.infoGradient
        DownloadProgressStatus.Downloading -> myColors.primaryGradient
        DownloadProgressStatus.Retrying -> myColors.errorGradient
    }

    var statusString = myStringResource(
        if (isWaiting) {
            Res.string.waiting
        } else {
            status.toStringResource()
        }
    )
    if (isError && errorReason != null) {
        statusString = errorReason.title
    }
    Column {
        val statusText = if (gotAnyProgress) {
            "${percent ?: "."}% $statusString"
        } else {
            statusString
        }
        SimpleStatus(
            string = statusText,
            color = if (isError) {
                myColors.error
            } else {
                LocalContentColor.current
            }
        )
        if (status != DownloadProgressStatus.Added) {
            Spacer(Modifier.height(2.5.dp))
            ProgressStatus(
                percent, background
            )
        }
    }
}

@Composable
private fun ProgressStatus(
    percent: Int?,
    background: Brush = myColors.primaryGradient,
) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(CircleShape)
            .border(Dp.Hairline, myColors.onSurface / 0.1f, CircleShape)
            .background(myColors.surface)
    ) {
        if (percent != null) {
            val w = (percent / 100f).coerceIn(0f..1f)
            Spacer(
                Modifier
                    .height(5.dp)
                    .fillMaxWidth(
                        animateFloatAsState(
                            w,
                            tween(100)
                        ).value
                    )
                    .background(background)
            )
        }
    }
}
