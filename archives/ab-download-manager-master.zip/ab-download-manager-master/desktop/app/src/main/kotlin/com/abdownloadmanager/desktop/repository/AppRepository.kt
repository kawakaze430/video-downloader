package com.abdownloadmanager.desktop.repository

import com.abdownloadmanager.shared.util.DownloadSystem
import ir.amirab.downloader.DownloadSettings
import com.abdownloadmanager.integration.Integration
import com.abdownloadmanager.integration.IntegrationResult
import com.abdownloadmanager.integration.IntegrationSettings
import com.abdownloadmanager.shared.IApplicationBackgroundTracker
import com.abdownloadmanager.shared.repository.BaseAppRepository
import com.abdownloadmanager.shared.storage.appsettings.BaseAppSettingsStorage
import com.abdownloadmanager.shared.util.ApiKeyUtil
import com.abdownloadmanager.shared.util.autoremove.RemovedDownloadsFromDiskTracker
import com.abdownloadmanager.shared.util.category.CategoryManager
import com.abdownloadmanager.shared.util.proxy.ProxyManager
import com.abdownloadmanager.shared.util.systemusage.SystemUsageMonitor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.*
import kotlin.time.Duration.Companion.milliseconds

class AppRepository(
    scope: CoroutineScope,
    appSettings: BaseAppSettingsStorage,
    proxyManager: ProxyManager,
    downloadSystem: DownloadSystem,
    downloadSettings: DownloadSettings,
    removedDownloadsFromDiskTracker: RemovedDownloadsFromDiskTracker,
    categoryManager: CategoryManager,
    private val integration: Integration,
    appUsageMonitor: SystemUsageMonitor,
    backgroundTracker: IApplicationBackgroundTracker,
) : BaseAppRepository(
    scope = scope,
    appSettings = appSettings,
    proxyManager = proxyManager,
    downloadSystem = downloadSystem,
    downloadSettings = downloadSettings,
    removedDownloadsFromDiskTracker = removedDownloadsFromDiskTracker,
    categoryManager = categoryManager,
    appUsageMonitor = appUsageMonitor,
    backgroundTracker = backgroundTracker,
) {
    init {
        combine(
            apiEnabled,
            apiPort,
            apiAuthEnabled,
            apiAuthKey,
        ) { apiEnabled, apiPort, apiAuthEnabled, apiAuthKey ->
            if (!apiEnabled) {
                return@combine null
            }
            IntegrationSettings(
                port = apiPort,
                apiKey = apiAuthKey
                    .takeIf { ApiKeyUtil.isValidKey(apiAuthKey) },
                apiKeyEnforced = apiAuthEnabled,
            )
        }
            .debounce(500.milliseconds)
            .onEach {
                if (it != null) {
                    integration.enable(it)
                } else {
                    integration.disable()
                }
            }.launchIn(scope)
        integration.integrationStatus.onEach { result ->
            //if there is an error in connection disable integration
            if (result is IntegrationResult.Fail) {
                apiEnabled.update { false }
            }
        }.launchIn(scope)
    }
}
