package com.abdownloadmanager.desktop.pages.addDownload.shared

import com.abdownloadmanager.shared.ui.configurable.RenderConfigurable
import com.abdownloadmanager.desktop.window.custom.BaseOptionDialog
import com.abdownloadmanager.shared.util.ui.myColors
import com.abdownloadmanager.shared.ui.widget.Text
import com.abdownloadmanager.shared.util.ui.WithContentColor
import com.abdownloadmanager.shared.util.div
import com.abdownloadmanager.desktop.window.moveSafe
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.window.WindowDraggableArea
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.v2.WindowBoundsProvider
import androidx.compose.ui.window.v2.WindowSizeProvider
import androidx.compose.ui.window.v2.rememberDialogState
import com.abdownloadmanager.shared.ui.configurable.Configurable
import com.abdownloadmanager.shared.ui.configurable.ConfigurableUiProps
import com.abdownloadmanager.shared.util.ui.MultiplatformVerticalScrollbar
import com.abdownloadmanager.shared.util.ui.theme.LocalUiScale
import com.abdownloadmanager.shared.util.ui.theme.myShapes
import ir.amirab.util.desktop.screen.applyUiScale
import java.awt.MouseInfo

@Composable
fun ExtraConfig(
    onDismiss: () -> Unit,
    configurables: List<Configurable<*>>,
) {
    val h = 250
    val w = 350
    val state = rememberDialogState(
        initialBoundsProvider = WindowBoundsProvider(
            sizeProvider = WindowSizeProvider.Fixed(
                size = DpSize(
                    height = h.dp,
                    width = w.dp,
                ).applyUiScale(LocalUiScale.current),
            )
        ),
    )
    BaseOptionDialog(
        onCloseRequest = onDismiss,
        state = state,
        minSize = DpSize(w.dp, h.dp),
    ) {
        LaunchedEffect(window){
            window.moveSafe(
                MouseInfo.getPointerInfo().location.run {
                    DpOffset(
                        x = x.dp,
                        y = y.dp
                    )
                }
            )
        }


        val shape = myShapes.defaultRounded
        Column(
            Modifier
                .fillMaxSize()
                .clip(shape)
                .border(2.dp, myColors.onBackground / 10, shape)
                .background(
                    Brush.linearGradient(
                        listOf(
                            myColors.surface,
                            myColors.background,
                        )
                    )
                )
        ) {
            WithContentColor(myColors.onBackground) {
                Column {
                    WindowDraggableArea(Modifier.fillMaxWidth()) {
                        Text(
                            "Extra Config", Modifier
                                .padding(vertical = 8.dp)
                                .fillMaxWidth()
                                .wrapContentWidth()
                        )
                    }
                    Divider()
                    Box {
                        val scrollState = rememberScrollState()
                        Column(
                            Modifier.verticalScroll(scrollState)
                        ) {
                            for ((index, cfg) in configurables.withIndex()) {
                                RenderConfigurable(
                                    cfg,
                                    ConfigurableUiProps(
                                        itemPaddingValues = PaddingValues(vertical = 8.dp, horizontal = 32.dp)
                                    )
                                )
                                if (index != configurables.lastIndex) {
                                    Divider()
                                }
                            }
                        }
                        MultiplatformVerticalScrollbar(
                            rememberScrollbarAdapter(scrollState),
                            Modifier.fillMaxHeight()
                                .align(Alignment.CenterEnd)
                        )
                    }
                }
            }
        }
    }
}
@Composable
private fun Divider() {
    Spacer(
        Modifier.fillMaxWidth()
            .height(1.dp)
            .background(myColors.onBackground / 10),
    )
}
