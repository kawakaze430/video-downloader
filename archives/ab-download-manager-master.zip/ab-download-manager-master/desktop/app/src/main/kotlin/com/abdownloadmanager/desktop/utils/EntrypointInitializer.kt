package com.abdownloadmanager.desktop.utils

import com.abdownloadmanager.desktop.AppArguments
import com.abdownloadmanager.desktop.NativeExtractor
import com.abdownloadmanager.shared.util.schemakt.initializeForABDM
import io.github.amir1376.schemakt.Schema
import io.github.vinceglb.filekit.FileKit
import ir.amirab.util.guardedEntry
import ir.amirab.util.logger.AppLogger

enum class EntryType {
    GUI,
    CLI,
    NativeMessaging,
}

object EntrypointInitializer {
    private val booted = guardedEntry()
    fun boot(
        debug: Boolean = false,
        entryType: EntryType
    ) {
        booted.action {
            AppArguments.update {
                it.copy(
                    debug = debug,
                )
            }
            AppProperties.boot(AppInfo.definedPaths.appPropertiesFile)

            // FileKit is currently only used for file and directory pickers.
            // Its initialization has no effect, but we keep it here for future-proofing.
            FileKit.init(
                appId = AppInfo.packageName,
                filesDir = AppInfo.definedPaths.configDir.toFile(),
                cacheDir = AppInfo.definedPaths.systemDir.toFile(),
            )
            NativeExtractor.init(
                cacheDir = AppInfo.definedPaths.nativeCacheDir
            )

            AppLogger.init(
                writeToConsole = false,
                logFilePath = AppInfo.definedPaths.logDir
                    .let {
                        it / when (entryType) {
                            EntryType.GUI -> "AppLog.log"
                            EntryType.CLI -> "CliLog.log"
                            EntryType.NativeMessaging -> "NativeMessaging.log"
                        }
                    }.takeIf {
                        AppInfo.isInDebugMode()
                    },
            )
            Schema.initializeForABDM()
        }
    }
}
