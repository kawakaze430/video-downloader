package com.abdownloadmanager.android.ui.configurable.comon.renderer

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abdownloadmanager.android.ui.configurable.ConfigTemplate
import com.abdownloadmanager.android.ui.configurable.TitleAndDescription
import com.abdownloadmanager.shared.ui.configurable.ConfigurableRenderer
import com.abdownloadmanager.shared.ui.configurable.ConfigurableUiProps
import com.abdownloadmanager.shared.ui.configurable.RenderSpinner
import com.abdownloadmanager.shared.ui.configurable.isConfigEnabled
import com.abdownloadmanager.shared.ui.configurable.item.SizeConfigurable
import com.abdownloadmanager.shared.ui.widget.DoubleTextField
import com.abdownloadmanager.shared.ui.widget.Text
import com.abdownloadmanager.shared.util.LocalSizeUnit
import com.abdownloadmanager.shared.util.LocalSpeedUnit
import ir.amirab.util.datasize.SizeConverter
import ir.amirab.util.datasize.SizeFactors
import ir.amirab.util.datasize.SizeUnit
import ir.amirab.util.datasize.SizeWithUnit
import ir.amirab.util.datasize.asConverterConfig

object SizeConfigurableRenderer : ConfigurableRenderer<SizeConfigurable> {
    @Composable
    override fun RenderConfigurable(
        configurable: SizeConfigurable,
        configurableUiProps: ConfigurableUiProps
    ) {
        RenderSpeedConfig(configurable, configurableUiProps)
    }

    @Composable
    private fun RenderSpeedConfig(cfg: SizeConfigurable, configurableUiProps: ConfigurableUiProps) {
        val value by cfg.stateFlow.collectAsState()
        val setValue = cfg::set

        val sizeUnit = LocalSizeUnit.current
        val speedUnit = LocalSpeedUnit.current
        val valueUnit = if (cfg.isSpeed) {
            speedUnit
        } else {
            sizeUnit
        }
        val allowedFactors = listOf(
            SizeFactors.FactorValue.Kilo,
            SizeFactors.FactorValue.Mega,
        )
        val units = allowedFactors.map {
            SizeUnit(
                factorValue = it,
                baseSize = valueUnit.baseSize,
                factors = valueUnit.factors
            )
        }
        val enabled = isConfigEnabled()

        var currentUnit by remember {
            mutableStateOf(
                SizeConverter.bytesToSize(
                    value,
                    valueUnit.copy(acceptedFactors = allowedFactors)
                ).unit
            )
        }
        var currentValue by remember(value) {
            val v = SizeConverter.bytesToSize(
                value, currentUnit.asConverterConfig()
            ).formatedValue().toDouble()
            mutableDoubleStateOf(v)
        }
        LaunchedEffect(currentValue, currentUnit) {
            setValue(
                SizeConverter.sizeToBytes(
                    SizeWithUnit(currentValue, currentUnit),
                )
            )
        }
        ConfigTemplate(
            configurableUiProps.modifier.padding(configurableUiProps.itemPaddingValues),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TitleAndDescription(cfg)
                }
            },
            value = {

            },
            nestedContent = {
                Row(
                    Modifier
                        .align(Alignment.End)
                        .padding(vertical = 8.dp)
                        .width(250.dp)
                ) {
                    val range = remember(cfg.range, currentUnit) {
                        val converter = currentUnit.asConverterConfig()
                        val first = SizeConverter.bytesToSize(
                            cfg.range.first,
                            converter,
                        ).value
                        val last = SizeConverter.bytesToSize(
                            cfg.range.last,
                            converter,
                        ).value
                        first..last
                    }
                    DoubleTextField(
                        value = currentValue,
                        onValueChange = {
                            currentValue = it
                        },
                        enabled = enabled,
                        range = range,
                        unit = 1.0,
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(8.dp))
                    RenderSpinner(
                        possibleValues = units,
                        value = currentUnit,
                        modifier = Modifier.Companion,
                        enabled = enabled,
                        onSelect = {
                            currentUnit = it
                        }
                    ) {
                        val prettified = remember(it) {
                            buildString {
                                append("$it")
                                if (cfg.isSpeed) {
                                    append("/s")
                                }
                            }
                        }
                        Text(prettified, Modifier.padding(horizontal = 4.dp))
                    }
                }
            }
        )
    }
}
