package com.abdownloadmanager.android.pages.add.single


import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import arrow.core.Some
import com.abdownloadmanager.android.pages.add.shared.*
import com.abdownloadmanager.android.ui.SheetHeader
import com.abdownloadmanager.android.ui.SheetTitle
import com.abdownloadmanager.android.ui.SheetTitleWithDescription
import com.abdownloadmanager.android.ui.SheetUI
import com.abdownloadmanager.resources.Res
import com.abdownloadmanager.shared.downloaderinui.add.CanAddResult
import com.abdownloadmanager.shared.pages.adddownload.shared.LastUsedLocationsProp
import com.abdownloadmanager.shared.pages.adddownload.shared.RememberFolderProp
import com.abdownloadmanager.shared.pages.adddownload.single.BaseAddSingleDownloadComponent
import com.abdownloadmanager.shared.ui.widget.*
import com.abdownloadmanager.shared.util.*
import com.abdownloadmanager.shared.util.downloaderror.DownloadErrorReason
import com.abdownloadmanager.shared.util.mvi.HandleEffects
import com.abdownloadmanager.shared.util.ui.WithContentAlpha
import com.abdownloadmanager.shared.util.ui.icon.MyIcons
import com.abdownloadmanager.shared.util.ui.myColors
import com.abdownloadmanager.shared.util.ui.theme.mySpacings
import com.abdownloadmanager.shared.util.ui.theme.myTextSizes
import com.abdownloadmanager.shared.util.ui.widget.MyIcon
import ir.amirab.downloader.connection.IResponseInfo
import ir.amirab.downloader.utils.OnDuplicateStrategy
import ir.amirab.util.compose.asStringSource
import ir.amirab.util.compose.resources.myStringResource

@Composable
fun ResponsiveDialogScope.AddSingleDownloadPage(
    component: AndroidAddSingleDownloadComponent,
    onDismiss: () -> Unit,
) {
    SheetUI(
        header = {
            SheetHeader(
                headerTitle = {
                    SheetTitle(
                        myStringResource(Res.string.new_download)
                    )
                },
                headerActions = {
                    TransparentIconActionButton(
                        MyIcons.close,
                        contentDescription = Res.string.close.asStringSource(),
                        onClick = onDismiss,
                    )
                }
            )
        }
    ) {
        val onDuplicateStrategy by component.onDuplicateStrategy.collectAsState()
        Column(
            Modifier
                .padding(horizontal = mySpacings.mediumSpace)
        ) {
            Column(
                Modifier
                    .weight(1f, false)
                    .verticalScroll(rememberScrollState())
            ) {
                val credentials by component.credentials.collectAsState()
                fun setLink(link: String) {
                    component.setCredentials(
                        credentials.copy(link = Some(link))
                    )
                }

                val showMoreInputs by component.showMoreInputs.collectAsState()

                HandleEffects(component) {
                    when (it) {
                        is BaseAddSingleDownloadComponent.Effects.Common -> {
                            when (it) {
                                is BaseAddSingleDownloadComponent.Effects.Common.SuggestUrl -> {
                                    setLink(it.link)
                                }
                            }
                        }

                        is BaseAddSingleDownloadComponent.Effects.Platform -> {
                            //
                        }
                    }
                }

                val canAddResult by component.canAddResult.collectAsState()
                Column {
                    UrlTextField(
                        text = credentials.link,
                        setText = {
                            setLink(it)
                        },
                        modifier = Modifier
                    )
                    AnimatedVisibility(showMoreInputs) {
                        Column {
                            Space()
                            val useCategory by component.useCategory.collectAsState()
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clickable {
                                            component.setUseCategory(!useCategory)
                                        }
                                        .padding(vertical = 4.dp)
                                ) {
                                    CheckBox(
                                        size = 16.dp,
                                        value = useCategory,
                                        onValueChange = { component.setUseCategory(it) }
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(myStringResource(Res.string.use_category))
                                }
                                Space()
                                Row {
                                    CategorySelect(
                                        modifier = Modifier.weight(1f),
                                        enabled = useCategory,
                                        categories = component.categories.collectAsState().value,
                                        selectedCategory = component.selectedCategory.collectAsState().value,
                                        onCategorySelected = {
                                            component.setSelectedCategory(it)
                                        },
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    CategoryAddButton(
                                        enabled = useCategory,
                                        modifier = Modifier,
                                        onClick = {
                                            component.addNewCategory()
                                        },
                                    )
                                }
                            }
                            Spacer(Modifier.size(8.dp))
                            val folderChangeResult = component.isFolderChangedResult.collectAsState().value
                            LocationTextField(
                                modifier = Modifier.fillMaxWidth(),
                                text = component.folder.collectAsState().value,
                                setText = {
                                    component.setFolder(it)
                                },
                                errorText = when (canAddResult) {
                                    CanAddResult.CantWriteInThisFolder -> myStringResource(Res.string.cant_write_to_this_folder)
                                    else -> null
                                },
                                lastUsedLocations = LastUsedLocationsProp(
                                    locations = component.lastUsedLocations.collectAsState().value,
                                    onRequestRemove = component::removeFromLastDownloadLocation,
                                ),
                                rememberFolder = RememberFolderProp(
                                    isEnabled = folderChangeResult.isChanged,
                                    value = component.rememberFolderAsDefault.collectAsState().value,
                                    onValueChange = component::setRememberFolderAsDefault,
                                    categoryName = folderChangeResult.categoryOrNull()?.name,
                                ),
                            )
                        }
                    }
                    val name by component.name.collectAsState()
                    Spacer(Modifier.size(8.dp))
                    NameTextField(
                        text = name,
                        setText = {
                            component.setName(it)
                        },
                        errorText = when (canAddResult) {
                            is CanAddResult.DownloadAlreadyExists -> {
                                if (onDuplicateStrategy == null) {
                                    myStringResource(Res.string.download_already_exists)
                                } else {
                                    null
                                }
                            }

                            CanAddResult.InvalidFileName -> myStringResource(Res.string.invalid_file_name)
                            else -> null
                        }.takeIf { name.isNotEmpty() }
                    )
                }
            }
            Column {
                Space()
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RenderFileTypeAndSize(component)
                    RenderResumeSupport(component, Modifier.weight(1f))
                    ConfigActionsButtons(component)
                }
                Space()
                MainActionButtons(component)
                ShowSolutionsOnDuplicateDownload(component)
                ShowAddToQueueDialog(
                    queueComponent = component.selectQueueComponent,
                    onRequestAddNewQueue = component.newQueuesAction
                )
                ExtraConfig(
                    isOpened = component.showMoreSettings,
                    onDismiss = { component.showMoreSettings = false },
                    configurables = component.configurables,
                )
            }
        }
    }

}

@Composable
private fun Space() {
    Spacer(Modifier.size(mySpacings.mediumSpace))
}

@Composable
private fun ShowSolutionsOnDuplicateDownload(
    component: AndroidAddSingleDownloadComponent,
) {
    val state = rememberResponsiveDialogState(false)
    val isOpen = component.showSolutionsOnDuplicateDownloadUi
    val onRequestClose = {
        component.showSolutionsOnDuplicateDownloadUi = false
    }
    state.OnFullyDismissed(onRequestClose)
    LaunchedEffect(isOpen) {
        if (isOpen) {
            state.show()
        } else {
            state.hide()
        }
    }
    val onDuplicateStrategy by component.onDuplicateStrategy.collectAsState()
    ResponsiveDialog(
        onDismiss = state::hide,
        state = state,
    ) {
        SheetUI(
            header = {
                SheetHeader(
                    headerTitle = {
                        SheetTitleWithDescription(
                            myStringResource(Res.string.select_a_solution),
                            myStringResource(Res.string.select_download_strategy_description),
                        )
                    }
                )
            },
            content = {
                Column(
                    Modifier
                        .padding(horizontal = 8.dp)
                        .padding(bottom = 8.dp)
                ) {
                    Spacer(Modifier.height(4.dp))
                    Divider()
                    Spacer(Modifier.height(4.dp))
                    Column {
                        OnDuplicateStrategySolutionItem(
                            isSelected = onDuplicateStrategy == OnDuplicateStrategy.AddNumbered,
                            title = myStringResource(Res.string.download_strategy_add_a_numbered_file),
                            description = myStringResource(Res.string.download_strategy_add_a_numbered_file_description),
                        ) {
                            component.setOnDuplicateStrategy(OnDuplicateStrategy.AddNumbered)
                            onRequestClose()
                        }
                        OnDuplicateStrategySolutionItem(
                            isSelected = onDuplicateStrategy == OnDuplicateStrategy.OverrideDownload,
                            title = myStringResource(Res.string.download_strategy_override_existing_file),
                            description = myStringResource(Res.string.download_strategy_override_existing_file_description),
                        ) {
                            component.setOnDuplicateStrategy(OnDuplicateStrategy.OverrideDownload)
                            onRequestClose()
                        }
                        OnDuplicateStrategySolutionItem(
                            isSelected = null,
                            title = myStringResource(Res.string.download_strategy_update_download_link),
                            description = myStringResource(Res.string.download_strategy_update_download_link_description),
                        ) {
                            component.updateDownloadCredentialsOfOriginalDownload()
                            onRequestClose()
                        }
                        OnDuplicateStrategySolutionItem(
                            isSelected = null,
                            title = myStringResource(Res.string.download_strategy_show_downloaded_file),
                            description = myStringResource(Res.string.download_strategy_show_downloaded_file_description),
                        ) {
                            component.openDownloadFileForCurrentLink()
                            onRequestClose()
                        }
                    }
                }
            }
        )

    }
}

@Composable
private fun OnDuplicateStrategySolutionItem(
    title: String,
    description: String,
    isSelected: Boolean?,
    onClick: () -> Unit,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(8.dp)
    ) {
        isSelected?.let {
            CheckBox(isSelected, { onClick() }, size = 12.dp)
        }
        Spacer(Modifier.width(8.dp))
        Column {
            Text(
                title,
                fontSize = myTextSizes.base,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            WithContentAlpha(0.7f) {
                Text(
                    text = description,
                    fontSize = myTextSizes.sm,
                    modifier = Modifier
                )
            }
        }

    }
}


@Composable
private fun Divider() {
    Spacer(
        Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(myColors.onBackground / 10),
    )
}


@Composable
fun RenderResumeSupport(
    component: AndroidAddSingleDownloadComponent,
    modifier: Modifier,
) {
    val checkResult by component.checkResponseResult.collectAsState()
    val fileInfo = checkResult?.getOrNull()?.takeIf { it.isSuccessFul }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .height(16.dp)
            .padding(horizontal = 8.dp)
    ) {
        val lineModifier = Modifier
            .weight(1f)
            .height(1.dp)
            .background(myColors.onBackground / 10)
        Box(lineModifier)
        val canAddToDownloads by component.canAddToDownloads.collectAsState()
        AnimatedVisibility(
            visible = canAddToDownloads && fileInfo != null,
        ) {
            fileInfo?.let { fileInfo ->
                if (fileInfo.resumeSupport) {
                    val iconModifier = Modifier
                        .padding(horizontal = 8.dp)
                        .size(16.dp)
                    if (fileInfo.resumeSupport) {
                        MyIcon(
                            icon = MyIcons.check,
                            contentDescription = null,
                            modifier = iconModifier,
                            tint = myColors.success
                        )
                    } else {
                        MyIcon(
                            icon = MyIcons.clear,
                            contentDescription = null,
                            modifier = iconModifier,
                            tint = myColors.error,
                        )
                    }
                }
            }
        }
        Box(lineModifier)


    }
}

@Composable
fun ConfigActionsButtons(component: AndroidAddSingleDownloadComponent) {
    val responseResult by component.checkResponseResult.collectAsState()
    val downloadErrorReason by component.lastError.collectAsState()
    val responseInfo = responseResult?.getOrNull()
    Row {
        IconActionButton(MyIcons.refresh, Res.string.refresh.asStringSource()) {
            component.refresh()
        }
        Spacer(Modifier.width(6.dp))
        val showMoreInputs by component.showMoreInputs.collectAsState()
        IconActionButton(
            if (showMoreInputs) {
                MyIcons.up
            } else {
                MyIcons.down
            },
            Res.string.more_options.asStringSource(),
        ) {
            component.setShowMoreInputs(!showMoreInputs)
        }
        Spacer(Modifier.width(6.dp))
        IconActionButton(
            MyIcons.settings,
            Res.string.settings.asStringSource(),
            indicateActive = component.showMoreSettings,
            requiresAttention = responseInfo?.requireBasicAuth ?: false
        ) {
            component.showMoreSettings = true
        }
        Spacer(Modifier.width(6.dp))
        downloadErrorReason?.let { downloadErrorReason ->
            DownloadErrorInfoButton(
                onClick = component::openDownloadErrorDialog,
                responseInfo = responseInfo,
                downloadErrorReason = downloadErrorReason,
            )
        }
    }
}

@Composable
private fun MainActionButtons(component: AndroidAddSingleDownloadComponent) {

    val onDuplicateStrategy by component.onDuplicateStrategy.collectAsState()
    val canAddResult by component.canAddResult.collectAsState()
    if (canAddResult is CanAddResult.DownloadAlreadyExists && onDuplicateStrategy == null) {
        Row {
            val buttonModifier = Modifier.weight(1f)
            ActionButton(
                text = myStringResource(Res.string.show_solutions),
                modifier = buttonModifier,
                onClick = { component.showSolutionsOnDuplicateDownloadUi = true },
            )
            if (component.shouldShowOpenFile.collectAsState().value) {
                Spacer(Modifier.width(8.dp))
                ActionButton(
                    text = myStringResource(Res.string.open_file),
                    modifier = buttonModifier,
                    onClick = { component.openExistingFile() },
                    onLongClick = { component.openExistingFile(useAppChooser = true) },
                )
            }
        }
    } else {
        val canAddToDownloads by component.canAddToDownloads.collectAsState()
        Column {
            if (onDuplicateStrategy != null) {
                ActionButton(
                    text = myStringResource(Res.string.change_solution),
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { component.showSolutionsOnDuplicateDownloadUi = true },
                )
                Space()
            }
            val isWebPage by component.isWebPage.collectAsState()
            if (isWebPage) {
                Row {
                    ActionButton(
                        text = myStringResource(Res.string.open_in_browser),
                        modifier = Modifier.fillMaxWidth(),
                        enabled = canAddToDownloads,
                        onClick = {
                            component.onRequestOpenLinkInBrowser()
                        },
                    )
                }
            } else {
                Row {
                    val buttonModifier = Modifier.weight(1f)
                    ActionButton(
                        text = myStringResource(Res.string.add),
                        modifier = buttonModifier,
                        enabled = canAddToDownloads,
                        onClick = {
                            component.selectQueueComponent.openAddToQueueDialog()
                        },
                        onLongClick = {
                            component.selectQueueComponent.fastConfirm()
                        }
                    )
                    Spacer(Modifier.width(8.dp))
                    PrimaryMainActionButton(
                        text = myStringResource(Res.string.download),
                        modifier = buttonModifier,
                        enabled = canAddToDownloads,
                        onClick = {
                            component.onRequestDownload()
                        },
                    )
                }

            }

        }
    }
}

@Composable
fun RenderFileTypeAndSize(
    component: AndroidAddSingleDownloadComponent,
) {
    val isLinkLoading by component.isLinkLoading.collectAsState()
    val linkCheckResult by component.checkResponseResult.collectAsState()
    val fileIconProvider = component.iconProvider
    val iconModifier = Modifier.size(mySpacings.iconSize)
    Box(
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            targetState = isLinkLoading,
            transitionSpec = {
                fadeIn() togetherWith fadeOut()
            }
        ) { loading ->
            if (loading) {
                LoadingIndicator(iconModifier)
            } else {
//                val extension = getExtension(fileInfo?.fileName ?: usersSetFileName) ?: "unknown"
                val downloadItem by component.downloadItem.collectAsState()
                val icon = fileIconProvider.rememberIcon(downloadItem.name)
                AnimatedContent(
                    linkCheckResult,
                ) { linkCheckResult ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        WithContentAlpha(1f) {
                            when (linkCheckResult) {
                                null -> {
                                    MyIcon(
                                        icon = MyIcons.question,
                                        contentDescription = null,
                                        modifier = iconModifier,
                                    )
                                }

                                else -> {
                                    MyIcon(
                                        icon,
                                        null,
                                        iconModifier
                                    )
                                    val size = component.getLengthString()
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        size.rememberString(),
                                        fontSize = myTextSizes.sm,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DownloadErrorInfoButton(
    onClick: () -> Unit,
    downloadErrorReason: DownloadErrorReason,
    responseInfo: IResponseInfo?,
) {
    val description = downloadErrorReason.title.asStringSource()
    Tooltip(description) {
        IconActionButton(
            onClick = {
                onClick()
            },
            contentDescription = description,
            icon = if (responseInfo?.requireBasicAuth == true) {
                MyIcons.lock
            } else {
                MyIcons.question
            },
            contentColor = myColors.error,
        )
    }
}

@Composable
private fun UrlTextField(
    text: String,
    setText: (String) -> Unit,
    errorText: String? = null,
    modifier: Modifier = Modifier,
) {
    MyTextFieldWithIcons(
        text,
        setText,
        myStringResource(Res.string.download_link),
        modifier = modifier.fillMaxWidth(),
        end = {
            MyTextFieldIcon(MyIcons.paste) {
                setText(
                    ClipboardUtil.read()
                        .orEmpty()
                )
            }
        },
        errorText = errorText
    )
}

@Composable
private fun NameTextField(
    text: String,
    setText: (String) -> Unit,
    errorText: String? = null,
) {
    MyTextFieldWithIcons(
        text,
        setText,
        myStringResource(Res.string.name),
        modifier = Modifier.fillMaxWidth(),
        errorText = errorText,
    )
}

