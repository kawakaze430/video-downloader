"""Downloader self-tests."""
